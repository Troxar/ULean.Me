﻿using NUnitLite;

namespace DiskTree;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}