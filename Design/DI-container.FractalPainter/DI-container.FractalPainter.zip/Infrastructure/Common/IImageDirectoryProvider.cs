namespace FractalPainting.Infrastructure.Common
{
    public interface IImageDirectoryProvider
    {
        string ImagesDirectory { get; }
    }
}