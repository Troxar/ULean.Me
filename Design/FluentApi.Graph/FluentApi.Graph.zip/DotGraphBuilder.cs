﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;

namespace FluentApi.Graph
{
	/*
	public class DotGraphBuilder
	{
		public static ... DirectedGraph(string graphName)
		{
			return ...
		}

	}
	*/
}