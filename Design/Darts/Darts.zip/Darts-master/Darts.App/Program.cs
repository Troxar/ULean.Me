﻿namespace Darts.App
{
	class Program
	{
		static void Main(string[] args)
		{
			new DartsConsoleUi().Run();
		}
	}
}
