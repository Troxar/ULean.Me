﻿namespace Darts.Domain.Models
{
	public enum SectionArea
	{
		Single = 1,
		Double = 2,
		Triple = 3
	}
}