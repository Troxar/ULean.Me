namespace Darts.Domain.Models.Dartboard
{
	public enum DartboardColor
	{
		Dark,
		Light,
		Green,
		Red
	}
}