﻿using System;

namespace Incapsulation.EnterpriseTask
{
    class DataBase
    {
        public static void OpenConnection()
        {
            throw new NotImplementedException();
        }

        public  static System.Collections.Generic.IEnumerable<Transaction> Transactions()
        {
            throw new NotImplementedException();
        }
    }
}