using NUnitLite;

namespace Inheritance.Geometry
{
    class Program
    {
        static void Main(string[] args)
        {
            new AutoRun().Execute(args);
        }
    }
}
